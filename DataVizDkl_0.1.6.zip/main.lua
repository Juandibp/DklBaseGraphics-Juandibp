--
-- Example2_1.lua
--
-- Döiköl Base Graphics Library
--
-- Copyright (c) 2017-2018 Armando Arce - armando.arce@gmail.com
--
-- This library is free software; you can redistribute it and/or modify
-- it under the terms of the MIT license. See LICENSE for details.
--

require "dkl/DklBaseGraphics"

local bg
local x
local y

function setup()
	size(500,350)
	local f = loadFont("data/Vera.ttf",11)
	textFont(f)
	bg = DklBaseGraphics:new(width(),height())
	x = {10,40,20,70,50}
	y = {20,70,50,30,10}
	data = {x,y,dimnames={"Perros","Gatos"}}
end

function draw()
	background(255)
	
	bg:par("mfrow",{2,2})
	bg:plot(x,x,{type="l"})
	bg:points(x,y)
	bg:text(x,y,x)
--	bg:box()
	bg:plot(y,y,{type="p"})
	bg:identify(y,y,y)
--	bg:text(y,y,y)
--	bg:box()
	bg:plot(x,y,{type="l"})
--	bg:box()
	bg:plot(y,x,{type="p"})
--	bg:box()
	
end

function windowResized(w,h)
	bg:resizeWindow(w,h)
end
